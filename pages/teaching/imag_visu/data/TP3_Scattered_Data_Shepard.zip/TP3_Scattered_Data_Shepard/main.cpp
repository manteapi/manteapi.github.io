#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

using namespace std;

void readData( const char * filename, vector<float>& longitude, vector<float>& latitude, vector<float>& densite, int size)
{
	ifstream dataFile(filename);
	char buffer[200];
	stringstream ss;
	for( int i = 0; i < size; ++i )
	{
		dataFile.getline(buffer, 100);
		ss << buffer;
		for( int j = 0; j < 4; ++j )
		{
			ss.getline(buffer, 100, ' ');
			if(j == 1){longitude[i] = atof(buffer);}
			if(j == 2){latitude[i] = atof(buffer);}
			if(j == 3){densite[i] = atof(buffer);}
			ss << "";
			ss.clear();
		}
		std::cout << endl;
	}
	dataFile.close();
}

void writeData(const char* filename, vector<float>& longitude, vector<float>& latitude, vector<float>& densite)
{
	ofstream outputFile;
	outputFile.open(filename);
	outputFile.precision(8);
	int size = densite.size();
	for(int i = 0; i < size; ++i)
	{
		outputFile << longitude[i] << " " << latitude[i] << " " << densite[i] << "\n";
	}
	outputFile.close();
}

int main ()
{
	int size = 8;
	vector<float> longitude(size);
	vector<float> latitude(size);
	vector<float> densite(size);

	//Load Data
	readData( "./../data.txt", longitude, latitude, densite, size);
	writeData( "./../output.txt", longitude, latitude, densite);

	return 0;
}
