Pour compiler avec CMake : 
cd build/
cmake ..
make
./gicao_project
