#ifndef UTILS_H
#define UTILS_H

#include <Eigen/Dense>
#include <glm/glm.hpp>
#include <vector>

using namespace std;
using namespace Eigen;

//typedef Vector2d vec;
typedef glm::vec2 vec;

//Sample code for decasteljau computation
/*
    vector<Vector2d> points;
    getControlPoints( "./../data/simple.txt", points);

    int resolution = 100;
    vector<float> t = seq(0, 1, resolution);

    //Bezier curve with Decasteljau polynom
    vector<Vector2d> curveCasteljau(100);
    for(int i = 0; i < resolution; ++i)
    {
        curveCasteljau[i] = decasteljau( points, t[i] );
    }
*/

vec decasteljau(vector<vec>& bi, float t);
void getPoints( const char* filename, vector<vec>& points );
vector<float> seq( float a, float b, int length );

#endif
