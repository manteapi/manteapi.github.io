#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "utils.h"

//typedef Vector2d vec;
typedef glm::vec2 vec;

vec decasteljau(vector<vec>& bi, float t)
{
    vec res;
    return res;
}

vector<float> seq(float a, float b, int length)
{
	vector<float> result(length);
	float l = (b-a)/(float)(length-1);
	for(int i = 0; i < length; ++i)
	{
        result[i] = a+i*l;
	}
	return result;
}

void getPoints( const char * filename, vector<vec>& points)
{
	int i = 0;
	char buffer[200];
	stringstream ss;
	ifstream file(filename);

	if(file.is_open())
	{
		while( file.getline(buffer, 100) )
		{
			ss << buffer;
			vec tmp;
			for( int j = 0; j < 2; ++j )
			{
				ss.getline(buffer, 100, ' '); //parsing
				if(j == 0){tmp[0] = atof(buffer);}
				if(j == 1){tmp[1] = atof(buffer);}
				ss << ""; //next parsing
				ss.clear();
			}
			points.push_back(tmp);
		}
		++i;
	}
	file.close();
}
