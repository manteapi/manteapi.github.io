install.packages("ggplot2")
install.packages("gridExtra")
library("ggplot2")
library("grid")
library("gridExtra")

y = read.table("./data.txt")$V1
N = length(y);
x = seq(0, N-1, by=1);

plotName<-ggplot(NULL, aes(x=x, y=y) ) + 
  geom_bar(stat="identity",fill="blue", colour="black") +
  ggtitle("Reference") + 
  theme( plot.title = element_text(colour="black", size=10))+
  theme( axis.ticks = element_blank(), axis.text.x = element_blank() )+
  theme( axis.text.y = element_text(colour="black", size=10)) +
  theme( axis.line = element_line(colour="black")) +
  theme( axis.title.x=element_blank() )+
  theme( axis.title.y=element_blank() )+
  coord_cartesian(ylim = c(0, 2.0));

#grid.layout permet d'afficher plusieurs plot sous forme de grille
#il suffit de remplacer(1,1) par le nombre de ligne et de colonne souhaité
#et de faire un print des plot de la grille.
png("Reference.png",width=6*200, height=2*200, res=200);
vplayout <- function(x, y) viewport(layout.pos.row = x, layout.pos.col = y)
pushViewport(viewport(layout = grid.layout(1, 1)))
print(plotName, vp = vplayout(1, 1))
dev.off();