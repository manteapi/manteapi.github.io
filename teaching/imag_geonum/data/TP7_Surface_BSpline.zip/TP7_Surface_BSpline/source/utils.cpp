#include <cstdlib>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>

#include "utils.h"

void writeBSplineSurface( const char* filename, vector<Vector3d>& points, int resolution )
{
    ofstream outputFile;
    outputFile.open(filename);
    outputFile.precision(8);
    for(int i = 0; i < resolution; ++i)
    {
        for(int j = 0; j < resolution; ++j)
        {
            outputFile << points[j*resolution+i][0] << " " << points[j*resolution+i][1] <<" " <<  points[j*resolution+i][2] << "\n";
        }
        outputFile << "\n";
    }
    outputFile.close();
}

vector<float> seq( float a, float b, int length )
{
    vector<float> result(length);
    float l = (b-a)/(float)(length-1);
    for(int i = 0; i < length; ++i)
    {
        result[i] = a+i*l;
    }
    return result;
}

BSpline::BSpline( const char * node_file, const char * knot_file, int _k, int _l)
{
    k = _k;
    l = _l;
    d.clear();
    u_knots.clear();
    v_knots.clear();
    getNode(node_file);
    getKnot(knot_file);
}

void BSpline::getNode(const char* node_file)
{
    int i = 0;
    char buffer[200];
    stringstream ss;
    ifstream file(node_file);

    if(file.is_open())
    {
        while( file.getline(buffer, 100) )
        {
            if( i == 0 )
            {
                ss << buffer;
                for(int j = 0; j < 2; ++j)
                {
                    ss.getline(buffer,100,' ');
                    if(j == 0){ m = atoi(buffer); }
                    if(j == 1){ n = atoi(buffer); }
                    ss << "";
                    ss.clear();
                }
            }
            else
            {
                Vector3d tmp;
                ss << buffer;
                for( int j = 0; j < 3; ++j )
                {
                    ss.getline(buffer, 200, ' '); //parsing
                    if(j == 0){tmp[0] = atof(buffer);}
                    if(j == 1){tmp[1] = atof(buffer);}
                    if(j == 2){tmp[2] = atof(buffer);}
                    ss << ""; //next parsing
                    ss.clear();
                }
                d.push_back(tmp);
            }
            ++i;
        }
    }
    file.close();
}


void BSpline::getKnot(const char* knot_file)
{
    u_knots.clear();
    v_knots.clear();
    int i = 0;
    char buffer[200];
    stringstream ss;
    ifstream file(knot_file);

    int u_count = 0;
    //int v_count = 0;
    int count = 0;
    float tmp = 0.0;

    if(file.is_open())
    {
        while( file.getline(buffer, 100) )
        {
            if( i == 0 )
            {
                ss << buffer;
                for(int j = 0; j < 2; ++j)
                {
                    ss.getline(buffer,100,' ');
                    if(j == 0){ u_count = atoi(buffer); }
                    //if(j == 1){ v_count = atoi(buffer); }
                    ss << "";
                    ss.clear();
                }
            }
            else
            {
                ss << buffer;
                ss.getline(buffer, 200, ' '); //parsing
                tmp = atof(buffer);
                ss.clear();
                if(count < u_count)
                    u_knots.push_back(tmp);
                else
                    v_knots.push_back(tmp);

                count++;
            }
            ++i;
        }
    }
    file.close();
}

void debugVec( vector<float>& vec )
{
    int size = vec.size();
    for(int i = 0; i < size; ++i)
    {
        std::cout << vec[i] << std::endl;
    }
}

void debugVec2( vector<Vector2d>& vec )
{
    int size = vec.size();
    for(int i = 0; i < size; ++i)
    {
        std::cout << vec[i][0] << ", " << vec[i][1] << std::endl;
    }
}

void debugVec3( vector<Vector3d>& vec )
{
    int size = vec.size();
    for(int i = 0; i < size; ++i)
    {
        std::cout << vec[i][0] << ", " << vec[i][1] << ", " << vec[i][2] << std::endl;
    }
}

void BSpline::checkKnots()
{
    int uSize = u_knots.size()-1;
    int vSize = v_knots.size()-1;
    if( uSize != m+k+1){ std::cerr << "u knots number ("<<u_knots.size()<<") not correct ! " << std::endl; }
    if( vSize != n+l+1){ std::cerr << "v knots number ("<<v_knots.size()<<") not correct ! " << std::endl; }
}

void BSpline::debugNodes()
{ 
    std::cout << "Nodes number : " << d.size() << std::endl;
    debugVec3( d ); 
    std::cout << std::endl;
}

void BSpline::debugKnots()
{
    std::cout << "U knots" << std::endl;
    debugVec( u_knots );
    std::cout << "V knots" << std::endl;
    debugVec( v_knots );
}
