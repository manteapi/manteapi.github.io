#Gnuplot commande
splot 'output.txt' using 1:2:3 with pm3d
