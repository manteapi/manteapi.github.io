#ifndef UTILS_H
#define UTILS_H

#include <Eigen/Dense>
#include <vector>

#undef NDEBUG
#include <assert.h>

using namespace std;
using namespace Eigen;


vector<float> seq(float a, float b, int length);
void debugVec3( vector<Vector3d>& vec);
void debugVec2( vector<Vector2d>& vec);
void debugVec( vector<float>& vec);
void writeBSplineSurface( const char* filename, vector<Vector3d>& points, int resolution );

class BSpline
{
    public :
        vector<Vector3d> points;    //surface points (result)
        vector<Vector3d> d;         //control points(dij)
        vector<float> u_knots;      //knots in u direction
        vector<float> v_knots;      //knots in v direction
        int m;                      //control point number in u direction - 1
        int n;                      //control point number in v direction - 1
        int k;                      //degree in u direction
        int l;                      //degree in v direction

    public :
        //Do not need to see that
        BSpline( const char* node_file, const char* knot_file, int _k, int _l);
        ~BSpline(){}
        void getNode(const char* node_file);
        void getKnot(const char* knot_file);
        vector<Vector3d>& getPoints(){return points;}
        const Vector3d& getNode(int i, int j) const {assert( i>=0 && i<=m);assert( j>=0 && j<=n);return d[j*(m+1) + i];}


        //Useful
        float getUKnot(int i){assert( i>=0 && i<=m+k+1);return u_knots[i];} //get i-th knots in u direction
        float getVKnot(int i){assert( i>=0 && i<=n+l+1);return v_knots[i];} //get i-th knots in v direction
        Vector3d& getNode(int i, int j){assert( i>=0 && i<=m);assert( j>=0 && j<=n);return d[j*(m+1) + i];} //get i,j control point

        void checkKnots();
        void debugNodes();
        void debugKnots();

        //Function which compute BSpline surface at (u,v) using DeBoor-Cox
        void generate(int resolution)
        {
            vector<float> u = seq(u_knots[k], u_knots[m+1], resolution);
            vector<float> v = seq(v_knots[l], v_knots[n+1], resolution);
            for(unsigned int i=0; i<u.size(); ++i)
            {
                for(unsigned int j=0; j<v.size(); ++j)
                {
                    points.push_back( bspline(u[i], v[j]) );
                }
            }
        }

        Vector3d bspline(float u, float v)
        {
            //TODO : Evaluate B-spline surface at (u,v)
            Vector3d res;
            return res;
        }
};

#endif

