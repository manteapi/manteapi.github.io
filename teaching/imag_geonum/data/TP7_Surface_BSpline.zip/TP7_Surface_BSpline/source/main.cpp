#include <cstdlib>
#include <iostream>
#include <vector>
#include <Eigen/Dense>
#include <cmath>
#include "utils.h"

using namespace std;
using namespace Eigen;

int main ()
{
    BSpline surface("../simple_d.txt", "../simple_t.txt", 2, 2);
    //surface.debugNodes();
    //surface.debugKnots();
    //surface.checkKnots();
    int resolution = 100;
    surface.generate(100);
    vector<Vector3d> points = surface.getPoints();
    writeBSplineSurface("../output.txt", points, resolution);
	return 0;
}
