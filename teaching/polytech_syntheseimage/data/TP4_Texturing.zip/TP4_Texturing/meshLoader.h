#ifndef MESH_LOADER_H
#define MESH_LOADER_H

#include <glm/glm.hpp>
#include <glm/gtc/type_precision.hpp> //i32vec3
#include <vector>
#include <string>
#include <array>

using namespace glm;
using namespace std;

class Mesh {
	public:
		Mesh(){}
		Mesh(const char* filename);
		Mesh(const char* file_obj, const char* file_tex);
		~Mesh();

		i32vec3 get_face(unsigned int i);
		vec3 get_vertex(unsigned int i);
		vec3 get_normal(unsigned int i);
		array<float,2> get_uvcoord(unsigned int i);

		vector< array<float,2> > triangleCoord();
		vector< array<float,2> > squareCoord();

		// length 
		unsigned int  nb_vertices;
		unsigned int  nb_faces;

		// data
		vector< vec3 > vertices;
		vector< vec3 > normals;
		vector< array<float, 2> > uvcoord;
		vector< unsigned int > faces;

		// info
		vec3 center;
		float radius;
};

#endif // MESH_LOADER_H
